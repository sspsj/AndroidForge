# Savr — Bug Audit, Fixes, and Verification Status

## Scope and honesty

This is a source-level audit and targeted hardening pass, not a guarantee that every possible bug has been eliminated. The project could not be compiled or executed in this environment because the Gradle wrapper distribution could not be downloaded (`UnknownHostException: services.gradle.org`). No real Android device/emulator was available for runtime verification. Items below distinguish code changes from checks that remain pending.

## Changes made in this pass

### Quick Save and manual URL handling

- Quick Save now uses the same metadata parser as manual bookmark entry.
- A URL is still saved if preview extraction fails; the user gets a distinct “preview unavailable” toast.
- URL extraction from Android share text and clipboard text is centralized in `UrlUtils`, so both paths handle URLs consistently.
- URL normalization now accepts uppercase HTTP/HTTPS schemes, normalizes valid URLs through OkHttp's URL parser, adds HTTPS to bare domains, and rejects malformed/non-web URLs.
- Manual save validates input before making a network request and reports invalid input instead of trying to fetch it.
- Manual save and Quick Save still rely on the repository's atomic insert result for duplicate handling.

### Preview extraction and network safety

- The metadata parser retains the best result across user-agent attempts rather than letting a later empty result overwrite useful metadata.
- Retries are reduced to three user agents and stop early when both title and image are available.
- Empty metadata results are returned as `null`, allowing Quick Save to correctly report that a preview was unavailable.
- HTTP requests have connect/read/call timeouts, reject unsuccessful HTTP responses and non-HTML content types, and cap HTML response bodies at 2 MiB.
- Redirected page URLs are used as the metadata base URL, improving relative image resolution and bookmark URL consistency.
- Relative and protocol-relative image URLs now use URI resolution rather than hand-built path concatenation.
- Description extraction now correctly falls back from Open Graph description to standard description metadata.

### Database reliability

- Quick Save's duplicate check, restore/unhide behavior, collection-only promotion, and insert now run in one Room transaction. This closes the previous check-then-insert race between concurrent saves.
- When a hidden or collection-only bookmark is restored, missing incoming metadata no longer overwrites existing non-null title, description, or image metadata.

### Lifecycle and background work

- Quick Save uses the Activity lifecycle coroutine scope, so the coroutine is cancelled when the Activity is destroyed instead of retaining the Activity through a standalone scope.
- The home screen's background metadata refresh resets its in-progress flag in `finally`, including when the database query or child tasks fail.

### Regression tests added

Added `LinkMetadataRegressionTest.kt` for URL normalization, uppercase schemes, malformed URLs, URL extraction from shared text, trailing punctuation, relative image URLs, and title fallback.

## Important issues still requiring review or runtime validation

These are not claimed as fixed:

1. **Build and test execution:** run `./gradlew testDebugUnitTest` and `./gradlew assembleDebug` in Android Studio or a network-enabled environment. Resolve any compiler/dependency errors before installing.
2. **Real-device Quick Save:** test share-sheet links from Chrome, YouTube, social apps, and a page that blocks crawlers. Some sites render metadata with JavaScript, require login, or block automated clients; those cannot be guaranteed to produce thumbnails.
3. **UI/UX and responsive layout:** Compose screens have not been exercised at small/large font scales, landscape, tablet widths, accessibility services, or Android edge-to-edge configurations.
4. **Memory/performance profiling:** no profiler run was possible. Large lists, Coil image loading, repeated navigation, and background refresh should be checked on device.
5. **Database migration validation:** test upgrades from each supported historical schema with a copy of real user data. Do not test migrations only against a fresh install.
6. **Collection hierarchy integrity:** parent assignment should reject self-parenting and descendant cycles if/when that operation is exposed. Recursive traversal should also defensively track visited IDs.
7. **Import/export:** test malformed browser HTML, duplicate URLs, deeply nested folders, and interrupted restore/backup flows.
8. **Network edge cases:** redirect chains, slow connections, unusual character encodings, image URLs that return errors, and local/private-network URLs still need dedicated tests.
9. **Duplicate equivalence:** URL tracking parameters and redirect aliases can still represent the same page as different saved URLs; canonicalization must be conservative to avoid removing meaningful query parameters.
10. **Accessibility and product polish:** confirm TalkBack labels, touch target sizes, loading/error/empty states, confirmation before destructive actions, and state restoration after process death.

## Commands to run before release

From the project root:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

Then install the generated debug APK and perform the real-device checklist above. A passing compile/test run is necessary but does not replace manual UI, migration, and lifecycle testing.
