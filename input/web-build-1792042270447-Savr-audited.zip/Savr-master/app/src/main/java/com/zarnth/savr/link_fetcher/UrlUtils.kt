package com.zarnth.savr.link_fetcher

import java.net.URI
import java.net.URLDecoder
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

object UrlUtils {
    /** Resolve relative, root-relative and protocol-relative URLs using browser URL semantics. */
    fun makeAbsoluteUrl(url: String, baseUrl: String): String = try {
        val reference = URI.create(url.trim())
        val base = URI.create(baseUrl)
        base.resolve(reference).normalize().toString()
    } catch (_: Exception) {
        url
    }

    /** Extract the first web URL from Android share/clipboard text and normalize it. */
    fun extractFirstHttpUrl(text: String): String? {
        val candidate = Regex(
            """https?://[^\s<>"']+|(?:www\.)?[^\s<>"']+\.[A-Za-z]{2,}(?:/[^\s<>"']*)?""",
            RegexOption.IGNORE_CASE
        ).find(text)?.value ?: return null
        val cleaned = candidate.trim().trimEnd('.', ',', ';', '!', '?', ')', ']', '}')
        return normalizeHttpUrl(cleaned)
    }

    /** Normalize a user-entered URL and reject malformed or non-web schemes. */
    fun normalizeHttpUrl(raw: String): String? {
        val trimmed = raw.trim()
        if (trimmed.isBlank()) return null
        val candidate = if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)) trimmed else "https://$trimmed"
        val parsed: HttpUrl = candidate.toHttpUrlOrNull() ?: return null
        return parsed.toString()
    }

    fun decodeUrl(url: String): String =
        runCatching { URLDecoder.decode(url, "UTF-8") }.getOrElse { url }
}
