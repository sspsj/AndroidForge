package com.zarnth.savr.link_fetcher

import okhttp3.OkHttpClient
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.Request
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import java.util.concurrent.TimeUnit

class NetworkFetcher {
    companion object {
        // Link previews only need the document head and modest page metadata.
        private const val MAX_HTML_BYTES = 2 * 1024 * 1024
    }

    private val client = OkHttpClient.Builder()
        .followRedirects(true)
        .followSslRedirects(true)
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .callTimeout(8, TimeUnit.SECONDS)
        .build()

    fun fetchDocument(url: String, agent: String): Document? {
        return try {
            val parsedUrl = url.toHttpUrlOrNull() ?: return null
            val request = Request.Builder()
                .url(parsedUrl)
                .header("User-Agent", agent)
                .header("Accept", "text/html,application/xhtml+xml;q=0.9,*/*;q=0.1")
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val contentType = response.header("Content-Type").orEmpty().lowercase()
                if (contentType.isNotBlank() &&
                    !contentType.contains("text/html") &&
                    !contentType.contains("application/xhtml+xml")
                ) return null

                val body = response.body ?: return null
                val source = body.source()
                // Read at most limit + 1 bytes so unexpectedly large responses cannot consume
                // unbounded memory. Reject oversized documents rather than parsing a corrupt tail.
                source.request((MAX_HTML_BYTES + 1).toLong())
                if (source.buffer.size > MAX_HTML_BYTES.toLong()) return null
                val bytes = source.readByteArray()
                if (bytes.isEmpty()) return null
                Jsoup.parse(bytes.inputStream(), body.contentType()?.charset()?.name(), response.request.url.toString())
            }
        } catch (_: Exception) {
            null
        }
    }
}
