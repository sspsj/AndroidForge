package com.zarnth.savr

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.zarnth.savr.domain.model.Bookmark
import com.zarnth.savr.domain.repository.BookmarkRepository
import com.zarnth.savr.domain.repository.SettingsRepository
import com.zarnth.savr.link_fetcher.LinkMetadataParser
import com.zarnth.savr.link_fetcher.UrlUtils
import org.koin.core.context.GlobalContext

class QuickSaveActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sharedText = intent?.getStringExtra(Intent.EXTRA_TEXT)?.trim()
        val quickSaveEnabled = GlobalContext.get().get<SettingsRepository>().getQuickSaveEnabled()

        if (sharedText.isNullOrBlank()) {
            finish()
            return
        }

        if (!quickSaveEnabled) {
            val forward = Intent(this, MainActivity::class.java).apply {
                action = Intent.ACTION_SEND
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, sharedText)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(forward)
            finish()
            return
        }

        val url = extractUrl(sharedText)
        if (url == null) {
            Toast.makeText(this, "No valid link found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val repository = GlobalContext.get().get<BookmarkRepository>()
        lifecycleScope.launch {
            // Metadata is best-effort: a site may block scrapers or be temporarily offline.
            // The URL must still be saved when preview extraction fails.
            val metadata = runCatching { LinkMetadataParser().parse(url) }.getOrNull()
            val bookmarkUrl = metadata?.url?.takeIf { it.isNotBlank() } ?: url
            try {
                val inserted = withContext(Dispatchers.IO) {
                    repository.insertToHome(
                        Bookmark(
                            url = bookmarkUrl,
                            title = metadata?.title?.takeIf { it.isNotBlank() },
                            description = metadata?.description?.takeIf { it.isNotBlank() },
                            imageUrl = metadata?.imageUrl?.takeIf { it.isNotBlank() }
                        )
                    )
                }
                val message = when {
                    !inserted -> "Already in Savr"
                    metadata == null -> "Saved link (preview unavailable)"
                    else -> "Saved to Savr"
                }
                Toast.makeText(this@QuickSaveActivity, message, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@QuickSaveActivity, "Couldn't save link", Toast.LENGTH_SHORT).show()
            } finally {
                finish()
            }
        }
    }

    private fun extractUrl(text: String): String? = UrlUtils.extractFirstHttpUrl(text)
}