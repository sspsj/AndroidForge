package com.zarnth.savr.link_fetcher

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull

/** Fetches the best available preview without allowing a later failed attempt to erase good data. */
class LinkMetadataParser(
    private val previewServiceFactory: () -> LinkPreviewService = { LinkPreviewService() }
) {
    companion object {
        // Keep retries bounded: each request has its own connect/read/call timeout.
        private val AGENTS = arrayOf(
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
            "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)",
            "Twitterbot/1.0"
        )
    }

    suspend fun parse(url: String): LinkPreviewData? = withContext(Dispatchers.IO) {
        if (url.toHttpUrlOrNull() == null) return@withContext null

        var best: LinkPreviewData? = null
        for (agent in AGENTS) {
            val candidate = try {
                previewServiceFactory().getLinkPreviewData(url, agent)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                null
            } ?: continue
            if (score(candidate) > score(best)) best = candidate
            // A title plus image is usually enough; avoid slow redundant requests.
            if (!candidate.title.isNullOrBlank() && !candidate.imageUrl.isNullOrBlank()) break
        }
        best?.takeIf { score(it) > 0 }
    }

    private fun score(data: LinkPreviewData?): Int {
        if (data == null) return 0
        return (if (!data.title.isNullOrBlank() && !data.title.equals("null", ignoreCase = true)) 4 else 0) +
            (if (!data.imageUrl.isNullOrBlank() && !data.imageUrl.equals("null", ignoreCase = true)) 3 else 0) +
            (if (!data.description.isNullOrBlank() && !data.description.equals("null", ignoreCase = true)) 2 else 0)
    }
}
