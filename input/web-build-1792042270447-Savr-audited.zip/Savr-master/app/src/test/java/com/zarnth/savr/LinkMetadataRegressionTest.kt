package com.zarnth.savr

import org.jsoup.Jsoup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import com.zarnth.savr.link_fetcher.MetadataExtractor
import com.zarnth.savr.link_fetcher.UrlUtils

class LinkMetadataRegressionTest {
    @Test
    fun normalizeHttpUrlAddsHttpsToBareDomain() {
        assertEquals("https://example.com/", UrlUtils.normalizeHttpUrl("example.com"))
    }

    @Test
    fun normalizeHttpUrlAcceptsUppercaseScheme() {
        assertEquals("https://example.com/path", UrlUtils.normalizeHttpUrl("HTTPS://example.com/path"))
    }

    @Test
    fun normalizeHttpUrlRejectsMalformedAndUnsupportedSchemes() {
        assertNull(UrlUtils.normalizeHttpUrl("not a url"))
        assertNull(UrlUtils.normalizeHttpUrl("file:///etc/passwd"))
    }

    @Test
    fun relativeOpenGraphImageResolvesAgainstFinalPageUrl() {
        val document = Jsoup.parse(
            "<html><head><meta property='og:image' content='/images/preview.png'></head></html>",
            "https://example.com/articles/story"
        )
        assertEquals(
            "https://example.com/images/preview.png",
            MetadataExtractor().extractImageUrl(document, document.baseUri())
        )
    }

    @Test
    fun sharedTextExtractsUrlAndStripsTrailingPunctuation() {
        assertEquals(
            "https://example.com/path",
            UrlUtils.extractFirstHttpUrl("Read this: https://example.com/path.")
        )
    }

    @Test
    fun sharedTextSupportsBareDomainsAndRejectsTextWithoutDomain() {
        assertEquals("https://example.com/", UrlUtils.extractFirstHttpUrl("example.com"))
        assertNull(UrlUtils.extractFirstHttpUrl("just some text"))
    }

    @Test
    fun relativeImageResolutionHandlesNestedPagePaths() {
        assertEquals(
            "https://example.com/articles/images/card.png",
            UrlUtils.makeAbsoluteUrl("images/card.png", "https://example.com/articles/story")
        )
    }

    @Test
    fun pageTitleIsFallbackWhenOpenGraphTitleIsMissing() {
        val document = Jsoup.parse("<html><head><title>Fallback title</title></head></html>")
        assertEquals("Fallback title", MetadataExtractor().extractTitle(document))
    }
}
